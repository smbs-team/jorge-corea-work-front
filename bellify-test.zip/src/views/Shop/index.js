import React, { Fragment } from 'react';

export default function Shop() {
    return (
        <Fragment>
            <p>Hola Tienda</p>
        </Fragment>
    );
}