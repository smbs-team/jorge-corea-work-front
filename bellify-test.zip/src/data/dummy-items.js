import ItemImage from '../assets/images/items/item.png';
import ItemImage2 from '../assets/images/items/item2.png';
import ItemImage3 from '../assets/images/items/item3.png';
import ItemImage4 from '../assets/images/items/item4.png';

const dummy = [
    {
        id: 1,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage
    },
    {
        id: 2,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage2
    },
    {
        id: 3,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage3
    },
    {
        id: 4,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage4
    },
    {
        id: 5,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage
    },
    {
        id: 6,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage2
    },
    {
        id: 7,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage3
    },
    {
        id: 8,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage4
    },
    {
        id: 9,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage
    },
    {
        id: 10,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage2
    },
    {
        id: 11,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage3
    },
    {
        id: 12,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage4
    },
    {
        id: 13,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage
    },
    {
        id: 14,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage2
    },
    {
        id: 15,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage3
    },
    {
        id: 16,
        name: 'Lorem Ipsum',
        price: '25.00 €',
        image: ItemImage4
    }
];

export default dummy;