import React from 'react';
import MenuHeader from './MenuHeader';

export default function Header() {
    return (
        <div className="Header">
           <MenuHeader />
        </div>
    );
}