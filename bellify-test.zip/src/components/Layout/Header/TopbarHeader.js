import React from 'react';

const TopbarHeader = () => {

	return (
		<div className="Header-topbar">
			Lorem ipsum dolor sit amet consectetur adipisicing elit
		</div>
	);
}

export default TopbarHeader;